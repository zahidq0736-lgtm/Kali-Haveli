using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public Camera playerCamera;
    public Light flashlight;
    public float walkSpeed = 3.2f;
    public float runSpeed = 5.1f;
    public float mouseSensitivity = 2.1f;
    public float interactDistance = 3f;
    public float gravity = -18f;

    CharacterController controller;
    float pitch;
    float verticalVelocity;
    bool flashlightOn = true;

    void Start()
    {
        controller = GetComponent<CharacterController>();
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    void Update()
    {
        if (KaaliHaveliBootstrap.Instance != null && KaaliHaveliBootstrap.Instance.GameEnded) return;
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
        }
        if (Input.GetMouseButtonDown(0))
        {
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
        }

        float mx = Input.GetAxis("Mouse X") * mouseSensitivity;
        float my = Input.GetAxis("Mouse Y") * mouseSensitivity;
        transform.Rotate(Vector3.up * mx);
        pitch = Mathf.Clamp(pitch - my, -78, 78);
        if (playerCamera) playerCamera.transform.localEulerAngles = new Vector3(pitch, 0, 0);

        float x = Input.GetAxisRaw("Horizontal");
        float z = Input.GetAxisRaw("Vertical");
        Vector3 move = transform.right * x + transform.forward * z;
        move = Vector3.ClampMagnitude(move, 1f);
        float speed = Input.GetKey(KeyCode.LeftShift) ? runSpeed : walkSpeed;
        if (controller.isGrounded && verticalVelocity < 0) verticalVelocity = -2f;
        verticalVelocity += gravity * Time.deltaTime;
        Vector3 velocity = move * speed;
        velocity.y = verticalVelocity;
        controller.Move(velocity * Time.deltaTime);

        if (Input.GetKeyDown(KeyCode.F) && flashlight)
        {
            flashlightOn = !flashlightOn;
            flashlight.enabled = flashlightOn;
        }
        if (Input.GetKeyDown(KeyCode.E)) Interact();
    }

    void Interact()
    {
        if (!playerCamera) return;
        Ray ray = new Ray(playerCamera.transform.position, playerCamera.transform.forward);
        if (Physics.Raycast(ray, out RaycastHit hit, interactDistance))
        {
            InteractableItem item = hit.collider.GetComponentInParent<InteractableItem>();
            if (item) item.Interact();
        }
    }
}
