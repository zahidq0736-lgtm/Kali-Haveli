using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System.Collections.Generic;

/// <summary>
/// Attach to an empty GameObject in a Unity 3D Core scene.
/// Builds a simple original haunted village/haveli prototype at runtime.
/// </summary>
public class KaaliHaveliBootstrap : MonoBehaviour
{
    public static KaaliHaveliBootstrap Instance;
    public Text objectiveText;
    public Text messageText;
    public int cluesNeeded = 3;

    public int CluesFound { get; private set; }
    public bool HasKey { get; private set; }
    public bool RitualComplete { get; private set; }
    public bool GameEnded { get; private set; }

    private readonly List<GameObject> clues = new List<GameObject>();
    private PlayerController player;
    private Light moonLight;

    void Awake() { Instance = this; }

    void Start()
    {
        RenderSettings.ambientLight = new Color(0.12f, 0.13f, 0.18f);
        RenderSettings.fog = true;
        RenderSettings.fogColor = new Color(0.035f, 0.04f, 0.06f);
        RenderSettings.fogMode = FogMode.Exponential;
        RenderSettings.fogDensity = 0.025f;

        BuildLighting();
        BuildGroundAndPath();
        BuildVillage();
        BuildHaveli();
        BuildPlayer();
        BuildCluesAndItems();
        BuildDayan();
        BuildUI();
        SetMessage("Kaali Haveli mein tumhara swagat hai... clues dhoondo.");
        UpdateObjective();
    }

    void BuildLighting()
    {
        GameObject moon = new GameObject("Moonlight");
        moonLight = moon.AddComponent<Light>();
        moonLight.type = LightType.Directional;
        moonLight.color = new Color(0.48f, 0.55f, 0.8f);
        moonLight.intensity = 0.35f;
        moon.transform.rotation = Quaternion.Euler(35, -25, 0);
    }

    GameObject Cube(string name, Vector3 pos, Vector3 scale, Color color, Transform parent = null)
    {
        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Cube);
        go.name = name;
        go.transform.position = pos;
        go.transform.localScale = scale;
        if (parent) go.transform.SetParent(parent);
        var r = go.GetComponent<Renderer>();
        r.material = new Material(Shader.Find("Standard"));
        r.material.color = color;
        return go;
    }

    GameObject Sphere(string name, Vector3 pos, float scale, Color color)
    {
        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        go.name = name;
        go.transform.position = pos;
        go.transform.localScale = Vector3.one * scale;
        var r = go.GetComponent<Renderer>();
        r.material = new Material(Shader.Find("Standard"));
        r.material.color = color;
        return go;
    }

    void BuildGroundAndPath()
    {
        Cube("Foggy Village Ground", new Vector3(0, -0.6f, 14), new Vector3(48, 1, 58), new Color(0.12f, 0.15f, 0.13f));
        Cube("Path to Haveli", new Vector3(0, -0.04f, 12), new Vector3(3.2f, 0.12f, 28), new Color(0.22f, 0.20f, 0.17f));
        for (int i = 0; i < 12; i++)
        {
            float z = -4 + i * 4.3f;
            Cube("Broken Fence L " + i, new Vector3(-5.5f, 0.35f, z), new Vector3(0.18f, 0.8f, 2.1f), new Color(0.18f, 0.12f, 0.09f));
            Cube("Broken Fence R " + i, new Vector3(5.5f, 0.35f, z + 1.2f), new Vector3(0.18f, 0.8f, 2.1f), new Color(0.18f, 0.12f, 0.09f));
        }
        for (int i = 0; i < 18; i++)
        {
            float x = (i % 2 == 0 ? -1 : 1) * Random.Range(8f, 19f);
            float z = Random.Range(-5f, 37f);
            Cube("Dead Tree Trunk", new Vector3(x, 1.4f, z), new Vector3(0.35f, 3.4f, 0.35f), new Color(0.12f, 0.08f, 0.06f));
            Cube("Dead Tree Branch", new Vector3(x + 0.6f, 2.4f, z), new Vector3(1.5f, 0.16f, 0.16f), new Color(0.12f, 0.08f, 0.06f)).transform.rotation = Quaternion.Euler(0, 0, Random.Range(-40f, 40f));
        }
    }

    void BuildVillage()
    {
        for (int i = 0; i < 4; i++)
        {
            float x = i < 2 ? -10 : 10;
            float z = 2 + (i % 2) * 10;
            Cube("Abandoned Village House", new Vector3(x, 1.4f, z), new Vector3(4.5f, 2.8f, 4f), new Color(0.19f, 0.17f, 0.15f));
            Cube("House Roof", new Vector3(x, 3.1f, z), new Vector3(5.2f, 0.35f, 4.7f), new Color(0.09f, 0.08f, 0.08f));
            Cube("Dark Window", new Vector3(x - 1.1f, 1.8f, z - 2.03f), new Vector3(0.7f, 0.75f, 0.05f), Color.black);
        }
    }

    void BuildHaveli()
    {
        Color wall = new Color(0.24f, 0.22f, 0.2f);
        Cube("Haveli Main Building", new Vector3(0, 2.3f, 28), new Vector3(15, 4.6f, 10), wall);
        Cube("Haveli Flat Roof", new Vector3(0, 4.75f, 28), new Vector3(16, 0.4f, 11), new Color(0.08f, 0.07f, 0.07f));
        Cube("Front Veranda", new Vector3(0, 0.4f, 21.8f), new Vector3(11, 0.8f, 2), new Color(0.16f, 0.14f, 0.13f));
        for (int i = 0; i < 5; i++)
            Cube("Veranda Pillar " + i, new Vector3(-4.8f + i * 2.4f, 1.8f, 21.8f), new Vector3(0.35f, 3.4f, 0.35f), new Color(0.12f, 0.11f, 0.1f));

        // Front opening and visible dark interior
        Cube("Left Door Frame", new Vector3(-1.15f, 1.5f, 22.75f), new Vector3(0.25f, 3f, 0.25f), new Color(0.07f, 0.05f, 0.04f));
        Cube("Right Door Frame", new Vector3(1.15f, 1.5f, 22.75f), new Vector3(0.25f, 3f, 0.25f), new Color(0.07f, 0.05f, 0.04f));
        Cube("Door Lintel", new Vector3(0, 3.05f, 22.75f), new Vector3(2.5f, 0.25f, 0.25f), new Color(0.07f, 0.05f, 0.04f));

        // Interior floor and walls
        Cube("Interior Floor", new Vector3(0, -0.05f, 28), new Vector3(13.5f, 0.2f, 8.5f), new Color(0.12f, 0.11f, 0.1f));
        Cube("Inner Wall Back", new Vector3(0, 2, 32.3f), new Vector3(13.5f, 4, 0.3f), wall);
        Cube("Inner Wall Left", new Vector3(-6.7f, 2, 28), new Vector3(0.3f, 4, 8.5f), wall);
        Cube("Inner Wall Right", new Vector3(6.7f, 2, 28), new Vector3(0.3f, 4, 8.5f), wall);

        // Locked inner door
        GameObject lockedDoor = Cube("Locked Inner Door", new Vector3(0, 1.4f, 32.0f), new Vector3(2.2f, 2.8f, 0.25f), new Color(0.12f, 0.06f, 0.04f));
        lockedDoor.AddComponent<InteractableItem>().Setup(InteractableItem.Kind.LockedDoor, "Andar ka darwaza band hai. Chabi chahiye.");
        Cube("Old Altar", new Vector3(0, 0.55f, 29.5f), new Vector3(2.4f, 1.1f, 1.1f), new Color(0.16f, 0.13f, 0.1f));
        GameObject diya = Sphere("Ritual Diya", new Vector3(0, 1.25f, 29.5f), 0.35f, new Color(0.95f, 0.38f, 0.06f));
        diya.AddComponent<InteractableItem>().Setup(InteractableItem.Kind.Diya, "Diya jal gaya... hawa mein kisi ki aahat hai.");
        Light diyaLight = diya.AddComponent<Light>();
        diyaLight.type = LightType.Point;
        diyaLight.range = 5;
        diyaLight.intensity = 0.8f;
        diyaLight.color = new Color(1f, 0.25f, 0.04f);
    }

    void BuildPlayer()
    {
        GameObject go = new GameObject("Player");
        go.transform.position = new Vector3(0, 1.1f, -4);
        CharacterController cc = go.AddComponent<CharacterController>();
        cc.height = 1.8f;
        cc.radius = 0.3f;
        player = go.AddComponent<PlayerController>();
        GameObject camGo = new GameObject("Player Camera");
        camGo.transform.SetParent(go.transform);
        camGo.transform.localPosition = new Vector3(0, 0.55f, 0);
        Camera cam = camGo.AddComponent<Camera>();
        cam.fieldOfView = 78;
        cam.farClipPlane = 75;
        camGo.AddComponent<AudioListener>();
        player.playerCamera = cam;
        GameObject flashlight = new GameObject("Flashlight");
        flashlight.transform.SetParent(camGo.transform);
        flashlight.transform.localPosition = new Vector3(0, 0, 0.2f);
        Light fl = flashlight.AddComponent<Light>();
        fl.type = LightType.Spot;
        fl.range = 18;
        fl.spotAngle = 55;
        fl.intensity = 2.4f;
        fl.color = new Color(0.75f, 0.82f, 1f);
        player.flashlight = fl;
    }

    void BuildCluesAndItems()
    {
        AddPickup("Torn Diary Page", new Vector3(-3, 0.35f, 25), InteractableItem.Kind.Clue, "Diary clue: 'Amavas ki raat, diya teen baar jalana...'");
        AddPickup("Broken Anklet", new Vector3(3, 0.35f, 27), InteractableItem.Kind.Clue, "Clue mila: payal ki awaaz Dayan ke aane ka ishara hai.");
        AddPickup("Red Thread", new Vector3(-4, 0.35f, 30), InteractableItem.Kind.Clue, "Clue mila: laal dhaaga purane mandir ka nishaan hai.");
        AddPickup("Haveli Key", new Vector3(4, 0.35f, 30), InteractableItem.Kind.Key, "Purani chabi mil gayi!");
    }

    void AddPickup(string name, Vector3 pos, InteractableItem.Kind kind, string message)
    {
        GameObject item = Sphere(name, pos, 0.42f, kind == InteractableItem.Kind.Key ? new Color(0.9f, 0.7f, 0.2f) : new Color(0.35f, 0.8f, 0.65f));
        item.AddComponent<InteractableItem>().Setup(kind, message);
    }

    void BuildDayan()
    {
        GameObject witch = new GameObject("Dayan");
        witch.transform.position = new Vector3(0, 0, 37);
        GameObject body = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        body.name = "Shadow Body";
        body.transform.SetParent(witch.transform);
        body.transform.localPosition = new Vector3(0, 1.1f, 0);
        body.transform.localScale = new Vector3(0.65f, 1.2f, 0.65f);
        body.GetComponent<Renderer>().material.color = new Color(0.04f, 0.035f, 0.045f);
        GameObject head = Sphere("Pale Face", witch.transform.position + Vector3.up * 2.3f, 0.52f, new Color(0.55f, 0.5f, 0.48f));
        head.transform.SetParent(witch.transform);
        head.transform.localPosition = new Vector3(0, 2.3f, 0);
        SphereEyes(witch.transform);
        witch.AddComponent<DayanAI>();
    }

    void SphereEyes(Transform parent)
    {
        for (int i = 0; i < 2; i++)
        {
            GameObject eye = Sphere("Glowing Eye", parent.position + new Vector3(i == 0 ? -0.12f : 0.12f, 2.34f, -0.23f), 0.07f, new Color(1f, 0.02f, 0.02f));
            eye.transform.SetParent(parent);
            eye.transform.localPosition = new Vector3(i == 0 ? -0.12f : 0.12f, 2.34f, -0.23f);
            Light l = eye.AddComponent<Light>();
            l.type = LightType.Point; l.range = 1.5f; l.intensity = 0.7f; l.color = Color.red;
        }
    }

    void BuildUI()
    {
        GameObject canvasGO = new GameObject("Game UI");
        Canvas canvas = canvasGO.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvasGO.AddComponent<CanvasScaler>().uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        canvasGO.AddComponent<GraphicRaycaster>();
        GameObject eventGO = new GameObject("EventSystem");
        eventGO.AddComponent<EventSystem>();
        eventGO.AddComponent<StandaloneInputModule>();

        objectiveText = MakeText(canvasGO.transform, "Objective", new Vector2(0.02f, 0.9f), new Vector2(0.72f, 0.98f), 20, TextAnchor.UpperLeft);
        messageText = MakeText(canvasGO.transform, "Message", new Vector2(0.12f, 0.05f), new Vector2(0.88f, 0.18f), 22, TextAnchor.MiddleCenter);
        MakeText(canvasGO.transform, "Controls", new Vector2(0.02f, 0.01f), new Vector2(0.62f, 0.06f), 14, TextAnchor.LowerLeft).text = "WASD Move | Mouse Look | E Interact | F Flashlight | Shift Run";
    }

    Text MakeText(Transform parent, string name, Vector2 min, Vector2 max, int size, TextAnchor anchor)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent, false);
        RectTransform rt = go.AddComponent<RectTransform>();
        rt.anchorMin = min; rt.anchorMax = max;
        rt.offsetMin = Vector2.zero; rt.offsetMax = Vector2.zero;
        Text t = go.AddComponent<Text>();
        t.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
        t.fontSize = size; t.color = new Color(0.92f, 0.9f, 0.82f); t.alignment = anchor;
        t.horizontalOverflow = HorizontalWrapMode.Wrap;
        t.verticalOverflow = VerticalWrapMode.Overflow;
        return t;
    }

    public void RegisterClue()
    {
        CluesFound++;
        UpdateObjective();
    }
    public void GiveKey() { HasKey = true; UpdateObjective(); }
    public void CompleteRitual() { RitualComplete = true; UpdateObjective(); }
    public void SetMessage(string msg) { if (messageText) messageText.text = msg; }
    public void EndGame(bool won)
    {
        if (GameEnded) return;
        GameEnded = true;
        SetMessage(won ? "TUM BACH GAYE! Kaali Haveli ka raaz khul gaya." : "DAYAN NE TUMHE PAKAD LIYA... GAME OVER");
        if (player) player.enabled = false;
    }
    public void UpdateObjective()
    {
        if (!objectiveText) return;
        string ritual = RitualComplete ? "Complete" : "Pending";
        objectiveText.text = "KAALI HAVELI\nClues: " + CluesFound + "/" + cluesNeeded +
            "\nChabi: " + (HasKey ? "Mil gayi" : "Dhoondo") + "\nDiya ritual: " + ritual;
    }
}
