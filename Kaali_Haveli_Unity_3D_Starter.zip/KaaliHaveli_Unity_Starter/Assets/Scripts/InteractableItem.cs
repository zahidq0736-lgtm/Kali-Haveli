using UnityEngine;

public class InteractableItem : MonoBehaviour
{
    public enum Kind { Clue, Key, LockedDoor, Diya }
    public Kind kind;
    public string message;
    bool used;

    public void Setup(Kind itemKind, string itemMessage)
    {
        kind = itemKind;
        message = itemMessage;
    }

    public void Interact()
    {
        if (used && kind != Kind.LockedDoor) return;
        var game = KaaliHaveliBootstrap.Instance;
        if (!game) return;

        switch (kind)
        {
            case Kind.Clue:
                used = true;
                game.RegisterClue();
                game.SetMessage(message);
                gameObject.SetActive(false);
                break;
            case Kind.Key:
                used = true;
                game.GiveKey();
                game.SetMessage(message);
                gameObject.SetActive(false);
                break;
            case Kind.LockedDoor:
                if (!game.HasKey)
                {
                    game.SetMessage("Darwaza band hai. Pehle haveli ki chabi dhoondo.");
                    return;
                }
                if (game.CluesFound < 3)
                {
                    game.SetMessage("Darwaze par nishaan chamak rahe hain. Pehle 3 clues jama karo.");
                    return;
                }
                game.SetMessage("Darwaza khul gaya! Ab diya ritual poora karo.");
                transform.position = new Vector3(0, -5, 32);
                break;
            case Kind.Diya:
                if (game.CluesFound < 3 || !game.HasKey)
                {
                    game.SetMessage("Diya jalane se pehle 3 clues aur chabi zaroori hain.");
                    return;
                }
                game.CompleteRitual();
                game.SetMessage("Diya jal gaya! Ab gaon ke raaste se bhaago!");
                used = true;
                break;
        }
    }
}
