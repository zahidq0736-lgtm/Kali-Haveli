using UnityEngine;

public class DayanAI : MonoBehaviour
{
    public float activationDistance = 14f;
    public float chaseSpeed = 2.0f;
    public float catchDistance = 1.35f;
    Transform player;
    bool active;

    void Start()
    {
        var p = GameObject.Find("Player");
        if (p) player = p.transform;
    }

    void Update()
    {
        if (!player || KaaliHaveliBootstrap.Instance == null || KaaliHaveliBootstrap.Instance.GameEnded) return;
        float distance = Vector3.Distance(transform.position, player.position);
        if (distance < activationDistance) active = true;
        if (!active) return;

        Vector3 target = new Vector3(player.position.x, transform.position.y, player.position.z);
        transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(target - transform.position), Time.deltaTime * 2.2f);
        transform.position = Vector3.MoveTowards(transform.position, target, chaseSpeed * Time.deltaTime);

        if (distance < catchDistance)
        {
            bool won = KaaliHaveliBootstrap.Instance.RitualComplete && player.position.z < 15f;
            KaaliHaveliBootstrap.Instance.EndGame(won);
        }
    }
}
