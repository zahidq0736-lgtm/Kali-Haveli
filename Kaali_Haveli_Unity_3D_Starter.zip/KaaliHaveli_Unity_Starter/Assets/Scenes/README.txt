Unity starter scene note:
Create a new empty scene in Unity 2022.3 LTS. Add an empty GameObject named Bootstrap and attach KaaliHaveliBootstrap.cs.
The bootstrap builds the prototype at runtime. Save the scene as KaaliHaveli.unity and add it to Build Settings.
