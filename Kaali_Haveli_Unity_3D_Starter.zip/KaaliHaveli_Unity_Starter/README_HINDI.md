# Kaali Haveli — Unity 3D Android Horror Starter

Yeh **Unity project starter** hai, compiled APK nahi. Isme runtime par simple 3D village/haveli scene generate hota hai, first-person movement, flashlight, clues, key, diya puzzle, Dayan enemy aur win/lose UI ka base diya gaya hai.

## Recommended setup
- Unity Hub se **Unity 2022.3 LTS** ya newer LTS install karein.
- Android Build Support, Android SDK & NDK Tools, aur OpenJDK select karein.
- New **3D Core** project banayein, phir is zip ke `Assets/Scripts` folder ko apne project ke `Assets/` mein copy karein.
- `Assets/Scenes/KaaliHaveli.unity` starter placeholder hai; easiest route: project open karke empty scene mein `KaaliHaveliBootstrap` script wala GameObject banayein aur us par `KaaliHaveliBootstrap.cs` attach karein. Play dabayein.
- Android controls: project ke initial version mein keyboard controls PC testing ke liye hain. Mobile touch UI controls add karne ke liye README ke “Mobile controls” section ko follow karein.
- Build: File > Build Settings > Android > Switch Platform > Add Open Scenes > Build.

## PC testing controls
- WASD: move
- Mouse: look (click Game view first)
- Shift: run
- F: flashlight
- E: interact / collect clue / use key / light diya
- Esc: unlock cursor

## Gameplay loop
1. Gaon ke raaste se haveli mein jao.
2. Haveli ke andar teen clues collect karo.
3. Chabi uthao aur locked inner door tak jao.
4. Diya interact karke ritual puzzle complete karo.
5. Dayan se bacho; objective complete karke exit tak pahuncho.

## Mobile controls (next implementation step)
For production Android controls, create a Canvas with a left virtual joystick and right-side swipe-look area plus buttons for Run, Flashlight and Interact. Hook them into `PlayerController.SetMoveInput(Vector2)` and `SetLookInput(Vector2)`. This starter intentionally leaves touch UI as a separate step so the core game logic remains easy to edit.

## Important
This is a starter prototype. Replace primitive shapes with original models, add licensed/own audio, optimize lighting, test on target devices, and add proper mobile UI before publishing. Do not use copyrighted assets from another game.
